DB Name = qr
table name = qe_data