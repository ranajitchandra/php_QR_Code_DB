
<?php

include('phpqrcode/qrlib.php');
    
    $path = 'img/';
    $qrcode = $path.time().".png";
    QRcode :: png("Ranajit", $qrcode, 'H', 4, 4);

    echo "<img src='".$qrcode."'>";

    ?>