<?php

    // database connect
		
		$db = new mysqli("localhost", "root", "", "qr");


    // QR Code

        include('phpqrcode/qrlib.php');
        
        
		
		// QR data insert
		
		if(isset($_POST['submit'])){

            $name = $_POST["name"];
            $phone = $_POST["phone"];
            $email = $_POST["email"];
            $address = $_POST["address"];
            $path = 'img/';
            $qrcode = $path.uniqid().".png";

			$insert_sql_query = "INSERT INTO qr_data (name, phone, email, address, image) VALUES ('$name', '$phone', '$email', '$address', '$qrcode') ";
            
            $result = mysqli_query($db, $insert_sql_query);
            
            if($result == true){
                QRcode :: png($email, $qrcode, 'H', 4, 4);
            }
		}

        // Data Rettriv

        $display_sql_query = "SELECT * FROM qr_data";
        $display_query = mysqli_query($db, $display_sql_query);

        // echo $row["id"] ."<br/>";
        // echo $row["name"] ."<br/>";
        // echo $row["phone"] ."<br/>";
        // echo $row["email"] ."<br/>";
        // echo $row["address"] ."<br/>";
        
?> 





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <form action="" method="post">
        <input type="text" name="name" placeholder="Name" required> <br/>
        <input type="text" name="phone" placeholder="Phone  Number" required><br/>
        <input type="email" name="email" placeholder="Email" required><br/>
        <input type="text" name="address" placeholder="address" required><br/>
        <input type="submit" name="submit" value="Submit">
    </form>

    <?php
    while($row = mysqli_fetch_assoc($display_query)){ ?>

        
    <img src="<?php echo $row["image"]; ?>" width="150" height="150" > 



<?php } ?>



</body>
</html>